#pragma once
void task_case8();
void task_case9();
void task_case10();
void task_case18();
void task_case19();
void task_case20();
void menuNum();

