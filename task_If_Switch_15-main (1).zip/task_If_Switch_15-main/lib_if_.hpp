#pragma once
void task8();
void task9();
void task10();
void task18();
void task19();
void task20();
void task28();
void task29();
void task30();
void menuNum();

