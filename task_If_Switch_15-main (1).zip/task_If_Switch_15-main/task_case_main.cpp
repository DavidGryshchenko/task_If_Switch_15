#include <iostream>
#include "libSwitch.hpp"
using  namespace std;

int main() {
    menuNum();
    return 0;
}
